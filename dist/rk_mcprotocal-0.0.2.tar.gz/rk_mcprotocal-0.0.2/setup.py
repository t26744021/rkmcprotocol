from setuptools import setup, find_packages

setup(
    name="rk_mcprotocal",
    version="0.0.2",
    packages=find_packages(),
    install_requires=[
        # 在这里列出您的依赖项，例如:
        # 'requests',
        # 'numpy',
    ],
)

