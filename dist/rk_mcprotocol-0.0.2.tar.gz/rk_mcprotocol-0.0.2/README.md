- **項目名稱 / Project Name**：
    
    Python 連接 FX5U ，實現"讀取"和"寫入"功能<br>
    
    Python Connect to FX5U for "Read" and "Write" Functions<br>

- **支援 PLC / Support PLC**：
    
    FX5U (CPU Ethernet)

- **Youtube**：
    https://www.youtube.com/watch?v=UQ1ehUCmH3I&t=326s<br>

- **PyPI**：
    https://pypi.org/project/rk-mcprotocol/0.0.2/<br>

## Language / 語言

- [English README](docs/English_README.md)
- [中文 README](docs/Chinese_README.md)
